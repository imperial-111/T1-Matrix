after the downloads 


open the file and first install espeek application then install t1 matrix software


password is = 9198181